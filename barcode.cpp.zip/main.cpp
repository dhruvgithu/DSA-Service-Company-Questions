#include<bits/stdc++.h>
using namespace std;
int main(){
    long long barcode;
    cin>>barcode;
    string mapping="abcdefghij", result="";
    if(barcode==0) result ="a";
    else while (barcode){
    result=mapping[barcode%10]+result;  //barcode % 10: Extracts the last digit of the barcode.
    barcode=barcode/10; //Removes the last digit from the barcode for the next iteration.
    
}
cout<<result<<endl;
}