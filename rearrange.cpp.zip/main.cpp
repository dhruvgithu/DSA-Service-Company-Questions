#include <bits/stdc++.h>

using namespace std;

bool canRearrange(string s, string t) {
    // Step 1: Check if lengths are same
    if (s.length() != t.length()) {
        return false;
    }

    // Step 2: Sort both strings
    sort(s.begin(), s.end());
    sort(t.begin(), t.end());

    // Step 3: Compare sorted strings
    return s == t;
}

int main() {
    string s = "listen";
    string t = "silent";

    if (canRearrange(s, t)) {
        cout << "True" << endl;
    } else {
        cout << "False" << endl;
    }

    return 0;
}
