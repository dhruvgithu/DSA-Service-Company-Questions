//To determine if one string is an anagram of another, 
//we can compare the frequency of characters in both strings. 
//If the frequency of each character matches, the strings are anagrams.
#include <bits/stdc++.h>
using namespace std;
bool isAnagram(string s,string t){
    if (s.length()!=t.length()) return false;
    sort(s.begin(),s.end());
    sort(t.begin(),t.end());
    return s==t;
} 

    int main() {
    string s = "anagram", t = "nagaram";
    cout << (isAnagram(s, t) ? "true" : "false");

    s = "rat", t = "car";
    cout << (isAnagram(s, t) ? "true" : "false");

    return 0;
}
