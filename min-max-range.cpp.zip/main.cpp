#include <iostream>
#include <vector>
using namespace std;

int main() {
    int days, minRange, maxRange;
    cin >> days >> minRange >> maxRange;

    vector<int> temperatures(days);

    // Reading the temperatures
    for (int i = 0; i < days; i++) {
        cin >> temperatures[i];
    }

    // Printing temperatures not in the range [minRange, maxRange]
    for (int i = 0; i < days; i++) {
        if (temperatures[i] < minRange || temperatures[i] > maxRange) {
            cout << temperatures[i] << " ";
        }
    }

    return 0;
}
