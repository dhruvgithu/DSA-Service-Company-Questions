#include <iostream>
#include <vector>
using namespace std;

int main() {
    int numSize;
    cin >> numSize;
    vector<int> elements(numSize);
    for (int i = 0; i < numSize; i++) {
        cin >> elements[i];
        if (i > 0) elements[i] += elements[i - 1];
        cout << elements[i] << " ";
    }
    return 0;
}
