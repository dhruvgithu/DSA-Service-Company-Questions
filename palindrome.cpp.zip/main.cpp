#include <iostream>
using namespace std;

int main() {
    int num, rev = 0, temp;
    cin >> num;

    if (num < 0) {
        cout << "Invalid Input";
        return 0;
    }

    temp = num;
    while (temp > 0) {
        int digit = temp % 10;
        rev = rev * 10 + digit;
        temp = temp / 10;
    }

    if (rev == num)
        cout << "Palindrome";
    else
        cout << "Not a Palindrome";

    return 0;
}

// Problem Statement – Goutam and Tanul plays by telling numbers. Goutam says a
//number to Tanul. Tanul should first reverse the number and check if it is same as the
//original. If yes, Tanul should say “Palindromeˮ. If not, he should say “Not a
//. If the number is negative, print “Invalid Inputˮ. Help Tanul by writing a
//program.
//Sample Input 1 
//21212
//Sample Output 1 
//Palindrome
