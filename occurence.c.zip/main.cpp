#include<bits/stdc++.h>
using namespace std;
int main(){
int n;
cin>>n; 
int arr[n];
for(int i=0;i<n;i++)
cin>>arr[i];
unordered_map<int,int> freq;
for(int i=0;i<n;i++)
freq[arr[i]]++;
for(auto &p:freq)
cout<<p.first<<"occurs"<<p.second<<"times\n";
return 0;
}
//You’re given an array of integers, print the number of times each integer has
//occurred in the array.
//Example
//Input :
//10
//1 2 3 3 4 1 4 5 1 2
//Output :
//1 occurs 3 times
//2 occurs 2 times
//3 occurs 2 times
//4 occurs 2 times
// occurs 1 times   