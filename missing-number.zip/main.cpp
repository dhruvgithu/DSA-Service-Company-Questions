#include<bits/stdc++.h>
using namespace std;
int missingNumber(int arr[],int n){
    int sum=0; 
    int sum1 =0;
    for(int i=1;i<=n;i++){
        sum+=i;
    }
    for(int i=0;i<=n;i++){
        sum1=sum1+arr[i];
    }
    return sum-sum1;
}
int main(){
    int n=5;
    int arr[n]= {1,2,3,5};
    cout<<missingNumber(arr,n);
    return 0;
}