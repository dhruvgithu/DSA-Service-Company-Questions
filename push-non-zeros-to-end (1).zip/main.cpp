#include<bits/stdc++.h>
using namespace std;
void PushZeroesToEnd(int arr[],int n){
int j=0;   // j non-zero element ko place karne ke liye position track karega  jaise 2,3,6
for(int i=0;i<n;i++){  
if (arr[i]!=0) { // Agar non-zero element mile
swap (arr[i],arr[j++]); // usko jth position pe bhej do, phir j++
 } 
}
}

int main(){
    int arr[]={2,0,3,0,6};
    int n = sizeof(arr) / sizeof(arr[0]);
    PushZeroesToEnd (arr,n);
    for(int i=0;i<n;i++)
    cout<<arr[i]<<" ";
    return 0;
}

//Push Empty Packets to the End of the Array
//Problem: Given an array of integer values, find all empty packets
//(represented by 0 ) and push them to the end of the array.
//Input: arr = [2, 0, 3, 0, 5]
//Output: [2, 3, 5, 0, 0]
