//Write a function that takes an integer n as input and returns the sum of all prime numbers less than N.
//Input: 10
//Output: 17
//Explanation: prime no less than 10 are: 2, 3, 5, 7 //

#include<bits/stdc++.h>
using namespace std;
bool isPrime(int num){
    if (num<=1) return false;
    for(int i=2;i<=sqrt(num);i++)
    if(num%i==0) return false;
    return true;
}
int main()
{
    int n,sum=0;
    cin>>n;
    for(int i=2;i<n;i++)
    if(isPrime(i)) sum=sum+i;
    cout<<sum<<endl;
    return 0;
}