#include<bits/stdc++.h>
using namespace std;
int main(){
    int a[]={5,11,17,18,33};
    int largest,i;
    largest=a[0];
    for(int i=0;i<5;i++){
        if(a[i]>largest){
            
        
        largest=a[i];
        }
    }
   cout<<"The largest element in the array is "<<largest;
}