#include <bits/stdc++.h>
using namespace std;
int main(){
int n,i,flag=0;
cout<<"Enter a number:";
cin>>n;
if (n <= 1)
  {
      cout<<"Not a Prime Number";
      return 0;
  }
  for( i=2;i<n;i++){
      if (n %i == 0 ) {
      flag=1;
    }
}
   if(flag==0)
   cout<<"Number is prime";
  else
  cout<<"Number is Not Prime";
  return 0;
  }