#include <iostream>
#include <string>
#include <cctype>

bool isPalindrome(const std::string& s) {
    int left = 0;
    int right = s.length() - 1;

    while (left < right) {
        // Move left pointer to the next alphanumeric character
        while (left < right && !isalnum(s[left])) {
            left++;
        }
        // Move right pointer to the previous alphanumeric character
        while (left < right && !isalnum(s[right])) {
            right--;
        }

        // Compare characters in lowercase
        if (tolower(s[left]) != tolower(s[right])) {
            return false;
        }

        left++;
        right--;
    }

    return true;
}

int main() {
    std::string s1 = "A man, a plan, a canal: Panama";
    std::string s2 = "race a car";
    std::string s3 = " ";

    std::cout << std::boolalpha;
    std::cout << isPalindrome(s1) << std::endl; // Output: true
    std::cout << isPalindrome(s2) << std::endl; // Output: false
    std::cout << isPalindrome(s3) << std::endl; // Output: true

    return 0;
}
