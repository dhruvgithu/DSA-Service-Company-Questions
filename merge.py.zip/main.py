def merge_arrays(arr1, arr2):
   arr3 = arr1 + arr2
   arr3.sort()
   return arr3
arr1=[1,3,2,6]
arr2=[5,4,8,7]
arr3= merge_arrays(arr1,arr2)
for value in arr3:
 print(value,end=" ")