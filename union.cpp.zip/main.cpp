#include<bits/stdc++.h>
using namespace std;
vector<int> findUnion(vector<int>& arr1,vector<int>& arr2){
    set<int>st;
    vector<int> ans;
    for(int i=0;i<arr1.size();i++){
        st.insert(arr1[i]);
    }
    for(int i=0;i<arr1.size();i++){
        st.insert(arr2[i]);
    }
    for(auto it:st){
        ans.push_back(it);
    }
    return ans;
    
}
int main(){
    vector<int>arr1={1,2,3,4,6};
    vector<int>arr2={2,3,5};
    vector<int> res=findUnion(arr1,arr2);
    for(int i=0;i<res.size();i++){
        cout<<res[i]<<" ";
    }
    return 0;
}