#include<bits/stdc++.h>
using namespace std;
int main(){
    int n;
    cin>>n;
    int num=n;
    int sum=0;
    while(num!=0){
        int digit=num%10;
        sum+=digit;
        num=num/10;
    }
    if(n% sum==0){
        cout<<"Good number"<<endl;
    }
    else{
        cout<<"Bad number"<<endl;
    }
    return 0;
}