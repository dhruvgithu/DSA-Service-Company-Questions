//You are a given a string str of length n. You have to find the most frequent vowel in the string str
//Note: You may assume that str will always hav a unique most frequent vowel.
//Sample Test Case:
//Input:
//7 -> string length
//xayuaba
//Output:a

#include<bits/stdc++.h>
using namespace std;
char mostfrequentVowel(const string& str){
    int count[5]={0};
    for(char ch:str){
        if(ch=='a')count[0]++;
        else if(ch=='e')count[1]++;
        else if(ch='i')count[2]++;
        else if(ch='o')count[3]++;
        else if(ch=='u')count[4]++;
    }
    int maxIdx=0;
    for(int i=1;i<5;i++){
        if (count[i]>count[maxIdx]) maxIdx=i;
    }
    return "aeiou"[maxIdx];
}
int main()
{
    string str;
    cout<<"enter the string";
    cin>>str;
    cout<<"mostfrequentVowel:" << mostfrequentVowel(str)<<endl;
    return 0;
    
}