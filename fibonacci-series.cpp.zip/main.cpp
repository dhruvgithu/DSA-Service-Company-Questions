#include<bits/stdc++.h>
using namespace std;
int fib(int n ){
if(n<=1)
return n;
return fib(n-1)+fib(n-2);
}
int main(){
    int n=6;
    cout<<fib(n);
    return 0;
}                          
                                  OR
                                 
#include <iostream>
using namespace std;
int fib(int n) {
    if(n <= 1)
        return n;
    
    int prev2 = 0, prev1 = 1, current;
    for(int i = 2; i <= n; i++) {
        current = prev1 + prev2;
        prev2 = prev1;
        prev1 = current;
    }
    return current;
}

int main() {
    int n = 6;
    cout << fib(n); // Output: 8
    return 0;
}

