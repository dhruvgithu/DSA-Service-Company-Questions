#include<bits/stdc++.h>
using namespace std;
int main(){
string str = "Dhruv";
reverse(str.begin(),str.end());
cout<<str;
return 0;
}


//Problem Description:
//The function accepts a string ‘str’ as its argument. The function needs to reverse the order of
//the words in the string.
//Example:
//Input:
//str: "Dhruv"
//Output:
//vurhd 