//def differenceofSum(n. m)
//The function accepts two integers n, m as arguments Find the sum of all numbers in range from 1 to m(both inclusive) that are not divisible by n. Return difference between sum of integers not divisible by n with sum of numbers divisible by n.
//Assumption:
//n>0 and m>0
//Sum lies between integral range
//Example
//Input
//n:4
//m:20
//Output
//90   
#include<bits/stdc++.h>
using namespace std;
int differenceofSum(int n,int m){
    int sumdivisible=0;
    int sumnotdivisible=0;
    for(int i=0;i<m;i++){
        if(i%n==0){
            sumdivisible=sumdivisible+i;
        }
            else{
                sumnotdivisible =sumnotdivisible+i;
                
            }
            
        }
        return sumnotdivisible- sumdivisible;
    }
int main(){
    int n=4,m=20;
    cout<<"difference of Sum :"<< differenceofSum(n,m)<<endl;
    return 0;
}
