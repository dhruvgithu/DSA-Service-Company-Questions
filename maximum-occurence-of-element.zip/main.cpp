#include<bits/stdc++.h>
using namespace std;
int main(){
    int arr[]={4,2,3,4,3,6,5,6,7,3,4,8};
    int n = sizeof(arr)/sizeof(arr[0]); 
    unordered_map<int,int> freq;
    for(int i=0;i<n;i++)
        freq[arr[i]]++;
        
        for (auto x:freq)
        cout<<x.first <<" : " << x.second<<endl;
        return 0;
    }
     
// x.first yeah btata hai ki number of elements in std::array
//x.second occurence of each element
//Question 28. Given an array, we have to found the number of occurrences ofeach element in the array.
//Input: arr[] = {10,5,10,15,10,5};
//Output:
//10 : 3
//5: 2
 //15: 2