#include <bits/stdc++.h>
using namespace std;
int main() 
{
int t,cars,bikes;
cin>>t;
for(int i=0;i<t;i++)
{
    cin>>cars>>bikes;
    cout<<cars*4+bikes*2;
    cout<<"\n";
}
}