#include <bits/stdc++.h>
using namespace std;
int finduniqueOne(int arr[],int n){
int ans=0;
for(int i=0;i<n;i++)
ans^=arr[i];
return ans;
}
int main(){
    int arr[]={4,1,2,1,2};
    int n = sizeof(arr)/sizeof(arr[0]);
    cout<<finduniqueOne(arr,n);
    return 0;
}

//Problem: Find the element that appears only once in an array where
//every other element appears twice.

//Input: arr = [4, 1, 2, 1, 2]
//Output: 4