#include <bits/stdc++.h>
using namespace std;
int majorityElement(vector<int>v){
    int n=v.size();
    for(int i=0;i<n;i++){
        int count =0;
        for(int j=0;j<n;j++){
            if(v[i]=v[j]){
                count++;
            }
        }
        if(count>(n/2))
        return v[i];
    }
    return -1;
}

    int main() {
    std::vector<int> nums1 = {3, 2, 3};
    std::cout << majorityElement(nums1) << std::endl; 

    std::vector<int> nums2 = {2, 2, 1, 1, 1, 2, 2};
    std::cout << majorityElement(nums2) << std::endl;  

    return 0;
}
  
    